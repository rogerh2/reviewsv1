<?php
/** Gallery block **/

if(!class_exists('AQ_Gallery_Block')) {
    class AQ_Gallery_Block extends AQ_Block {

        //set and create block
        function __construct() {
            $block_options = array(
                'name' => 'Gallery',
                'size' => 'span6',
            );

            //create the block
            parent::__construct('aq_gallery_block', $block_options);
        }

        function form($instance) {

            $defaults = array(
                'post_number' => '5',
                'post_order' => '',
                'order_by' => '',
                'category' => '',
            );

            $instance = wp_parse_args($instance, $defaults);
            extract($instance);

            $args = array(
                'type'                     => 'gallery',
                'child_of'                 => 0,
                'parent'                   => '',
                'orderby'                  => 'name',
                'order'                    => 'ASC',
                'hide_empty'               => 1,
                'hierarchical'             => 1,
                'exclude'                  => '',
                'include'                  => '',
                'number'                   => '',
                'taxonomy'                 => 'ct_gallery',
                'pad_counts'               => false

            );
            $categories = get_categories( $args );
            $category_options = array('-1' => 'All Categories');

            foreach($categories as $one_category){
                $category_options = $category_options + array($one_category->term_id => $one_category->name);
            }

            $order_options = array(
                'ASC' => 'Ascending',
                'DESC' => 'Descending',
            );

            $order_by_options = array(
                'ID' => 'Order by Post ID',
                'author' => 'Order by Post author',
                'title' => 'Order by Post title',
                'name' => 'Order by Post name (slug)',
                'date' => 'Order by Post Date',
                'modified' => 'Order by Post Modified Date',
                'comment_count' => 'Order by number of comments',
                'rand' => 'Random order',
            );
            ?>

            <p class="description">
                <label for="<?php echo $this->get_field_id('title') ?>">
                    Title<br/>
                    <?php echo aq_field_input('title', $block_id, $title) ?>
                </label>
            </p>
            <p class="description">
                <label for="<?php echo $this->get_field_id('post_number') ?>">
                    Number of posts<br/>
                    <?php echo aq_field_input('post_number', $block_id, $post_number) ?>
                </label>
            </p>
            <p class="description half">
                <label for="<?php echo $this->get_field_id('category') ?>">
                    Select Category<br/>
                    <?php echo aq_field_select('category', $block_id, $category_options, $category) ?>
                </label>
            </p>
            <p class="description half">
                <label for="<?php echo $this->get_field_id('order_by') ?>">
                    Order By<br/>
                    <?php echo aq_field_select('order_by', $block_id, $order_by_options, $order_by) ?>
                </label>
            </p>
            <p class="description half">
                <label for="<?php echo $this->get_field_id('post_order') ?>">
                    Ordering Type<br/>
                    <?php echo aq_field_select('post_order', $block_id, $order_options, $post_order) ?>
                </label>
            </p>

        <?php

        }

        function block($instance) {
            extract($instance);
            if($category == '-1'){
                $get_page_id = get_option('id_gallery_page');
                if(isset($get_page_id)){
                    $category_link = get_permalink($get_page_id);
                }else{
                    $category_link = '#';
                }
            }else{
                $get_that_term = get_term($category, 'ct_services');
                $category_link = get_term_link($get_that_term, 'ct_services');
            }
            ?>

            <div class="middle-content-left">
                <?php if(!empty($title)){?>
                    <div class="title-holder margin-bottom-45">
                        <h2 class="title-divider">
                            <span><?php echo $title?></span>
                        </h2>
                    </div>
                <?php }?>
                    <div class="gallery-holder">
                    <?php
                    if($category == '-1'){
                        $args = array( 'post_status' => 'publish', 'post_type' => 'gallery', 'posts_per_page' => $post_number, 'orderby' => $order_by, 'order' => $post_order );
                    }else{
                        $args = array( 'post_status' => 'publish', 'post_type' => 'gallery', 'tax_query' => array(array('taxonomy' => 'ct_gallery','field' => 'term_id', 'terms' => $category)), 'posts_per_page' => $post_number, 'orderby' => $order_by, 'order' => $post_order );
                    }

                    // The Query
                    $the_query = new WP_Query($args);

                    if ($the_query->have_posts()): while ($the_query->have_posts()) : $the_query->the_post(); ?>
                        <?php
                        if (get_post_format()) {
                            $post_format = get_post_format();
                        } else {
                            $post_format = 'standard';
                        }
                        $gallery_builder = 'yes';
                        get_template_part('/templates/parts/format', $post_format);
                        global $gallery_builder;
                        ?>
                    <?php endwhile; ?>
                    <?php endif;?>
                </div>
            </div>
        <?php
        }

    }
}