<?php
/** Events block **/

if(!class_exists('AQ_Events_Block')) {
    class AQ_Events_Block extends AQ_Block {

        //set and create block
        function __construct() {
            $block_options = array(
                'name' => 'Events',
                'size' => 'span6',
            );

            //create the block
            parent::__construct('aq_events_block', $block_options);
        }

        function form($instance) {

            $defaults = array(
                'post_number' => '5',
                'post_order' => '',
                'order_by' => '',
                'category' => '',
            );

            $instance = wp_parse_args($instance, $defaults);
            extract($instance);

            $args = array(
                'type'                     => 'events',
                'child_of'                 => 0,
                'parent'                   => '',
                'orderby'                  => 'name',
                'order'                    => 'ASC',
                'hide_empty'               => 1,
                'hierarchical'             => 1,
                'exclude'                  => '',
                'include'                  => '',
                'number'                   => '',
                'taxonomy'                 => 'ct_events',
                'pad_counts'               => false

            );
            $categories = get_categories( $args );
            $category_options = array('-1' => 'All Categories');

            foreach($categories as $one_category){
                $category_options = $category_options + array($one_category->term_id => $one_category->name);
            }

            $order_options = array(
                'ASC' => 'Ascending',
                'DESC' => 'Descending',
            );

            $order_by_options = array(
                'ID' => 'Order by Post ID',
                'author' => 'Order by Post author',
                'title' => 'Order by Post title',
                'name' => 'Order by Post name (slug)',
                'date' => 'Order by Post Date',
                'modified' => 'Order by Post Modified Date',
                'comment_count' => 'Order by number of comments',
                'rand' => 'Random order',
            );
            ?>

            <p class="description">
                <label for="<?php echo $this->get_field_id('title') ?>">
                    Title<br/>
                    <?php echo aq_field_input('title', $block_id, $title) ?>
                </label>
            </p>
            <p class="description">
                <label for="<?php echo $this->get_field_id('post_number') ?>">
                    Number of posts<br/>
                    <?php echo aq_field_input('post_number', $block_id, $post_number) ?>
                </label>
            </p>
            <p class="description half">
                <label for="<?php echo $this->get_field_id('category') ?>">
                    Select Category<br/>
                    <?php echo aq_field_select('category', $block_id, $category_options, $category) ?>
                </label>
            </p>
            <p class="description half">
                <label for="<?php echo $this->get_field_id('order_by') ?>">
                    Order By<br/>
                    <?php echo aq_field_select('order_by', $block_id, $order_by_options, $order_by) ?>
                </label>
            </p>
            <p class="description half">
                <label for="<?php echo $this->get_field_id('post_order') ?>">
                    Ordering Type<br/>
                    <?php echo aq_field_select('post_order', $block_id, $order_options, $post_order) ?>
                </label>
            </p>

        <?php

        }

        function block($instance) {
            extract($instance);
            if($category == '-1'){
                $get_page_id = get_option('id_events_page');
                if(isset($get_page_id)){
                    $category_link = get_permalink($get_page_id);
                }else{
                    $category_link = '#';
                }
            }else{
                $get_that_term = get_term($category, 'ct_events');
                $category_link = get_term_link($get_that_term, 'ct_events');
            }
            ?>
            <div class="top-content-home">
                <?php if(!empty($title)){?>
                    <div class="title-holder margin-bottom-45">
                        <h2 class="title-divider">
                            <span><?php echo $title?></span>                              
                        </h2>
                    </div>
                <?php }?>
                <?php
                if($category == '-1'){
                    $args = array( 'post_status' => 'publish', 'post_type' => 'events', 'posts_per_page' => $post_number, 'orderby' => $order_by, 'order' => $post_order );
                }else{
                    $args = array( 'post_status' => 'publish', 'post_type' => 'events', 'tax_query' => array(array('taxonomy' => 'ct_events','field' => 'term_id', 'terms' => $category)), 'posts_per_page' => $post_number, 'orderby' => $order_by, 'order' => $post_order );
                }

                // The Query
                $the_query = new WP_Query($args);

                if ($the_query->have_posts()): while ($the_query->have_posts()) : $the_query->the_post(); ?>
                    <?php

                    /*$event_date = explode('-', get_post_meta($the_query->post->ID, 'tk_event_date', true));
                    $event_time = explode(':', get_post_meta($the_query->post->ID, 'tk_event_time', true));*/

                    $main_event_date = get_post_meta($the_query->post->ID, 'tk_event_datetime', true); 
                    $datedate        = date('d-m-Y', $main_event_date); 
                    $datetime        = date('H:i:s', $main_event_date); 
                    $event_date      = explode('-', $datedate); 
                    $event_time      = explode(':', $datetime); 

                    $event_address = get_post_meta($the_query->post->ID, 'tk_event_address', true);
                    $event_duration = get_post_meta($the_query->post->ID, 'tk_event_duration', true);
                    $video_link = get_post_meta($the_query->post->ID, 'tk_video_link', true);
                    $attachments  = get_post_meta($the_query->post->ID, 'tk_repeatable', true);
                    $check_post_format = get_post_format($the_query->post->ID);
                    $random_str =  substr(md5(rand()), 0, 6);
                    ?>
                <div class="row-fluid margin-bottom-builder">
                    <div class="span12 margin-left-0">
                        <div class="<?php if($instance['size'] == 'span12'){echo 'span6';}else{echo 'span12 margin-left-0';}?>">
                            <?php if ($check_post_format == 'video') {?>
                                <div class="top-content-image <?php if(!$video_link){echo 'events-title-no-image';}?>">
                                    <a href="<?php the_permalink()?>">
                                        <ul class="countdown-<?php echo $random_str?>"></ul>
                                        <?php if($video_link){tk_video_player($video_link);}?>
                                    </a>
                                </div>
                            <?php } elseif ($check_post_format == 'gallery') {?>
                            
                            
                                <?php if(!empty ($attachments[0])){?>
                                    <div class="causes-block-gallery  page-build-small">                                       
                                            <div class="flexslider">
                                                <ul class="slides">
                                                    <?php
                                                        foreach($attachments as $attach) {
                                                            echo '<li><img src="'.tk_get_thumb(770, 398, $attach).'" alt="'.get_the_title().'" title="'.get_the_title().'"/></li>';
                                                        }
                                                    ?>
                                                </ul>
                                            </div><!-- flex slider -->                                        
                                    </div>
                                <?php }?>
                            
                            
                                <div class="top-content-image page-build-small <?php if(empty($attachments[0])){echo 'events-title-no-image';}?>">
                                    <a href="<?php the_permalink()?>">
                                        <ul class="countdown-<?php echo $random_str?>"></ul>                                        
                                        <?php if(count($event_date) > 1 && count($event_time) > 1 && $instance['size'] != 'span2'){?>
                                            <script type="text/javascript">
                                                jQuery(document).ready(function($){
                                                    $('.countdown-<?php echo $random_str?>').countdown({alwaysExpire: true, expiryText: ' ',until: new Date(<?php echo $event_date[2]?>, <?php echo $event_date[1]?>-1, <?php echo $event_date[0]?>, <?php echo $event_time[0]?>, <?php echo $event_time[1]?>, 00), layout: '<li><span>{dn}</span> <p><?php _e('days', 'tkingdom')?></p></li> <?php if($instance['size'] == 'span12' || $instance['size'] == 'span6'){?><li><span>{hnn}</span> <p><?php _e('hours', 'tkingdom')?></p></li> <li><span>{mnn}</span> <p><?php _e('minutes', 'tkingdom')?></p></li> <li><span>{snn}</span> <p><?php _e('seconds', 'tkingdom')?></p></li><?php }?>', compact: true, timezone:new Date().getTimezoneOffset()/60 * -1});
                                                });
                                            </script>
                                        <?php }?>
                                    </a>
                                </div>
                            
                            
                            
                            <?php } else{?>
                                <?php
                                    $post_thumbnail = wp_get_attachment_image_src( get_post_thumbnail_id($the_query->post->ID), 'home-events' );
                                    $post_thumbnail_src = $post_thumbnail['0'];
                                    ?>
                                    <div class="top-content-image <?php if(!has_post_thumbnail()){echo 'events-title-no-image';}?>">
                                        <a href="<?php the_permalink()?>">
                                            <ul class="countdown-<?php echo $random_str?>"></ul>
                                            <?php if(has_post_thumbnail()){the_post_thumbnail('home-events');}?>
                                            <?php if(count($event_date) > 1 && count($event_time) > 1 && $instance['size'] != 'span2'){?>
                                                <script type="text/javascript">
                                                    jQuery(document).ready(function($){
                                                        $('.countdown-<?php echo $random_str?>').countdown({alwaysExpire: true, expiryText: ' ', until: new Date(<?php echo $event_date[2]?>, <?php echo $event_date[1]?>-1, <?php echo $event_date[0]?>, <?php echo $event_time[0]?>, <?php echo $event_time[1]?>, 00), layout: '<li><span>{dn}</span> <p><?php _e('days', 'tkingdom')?></p></li> <?php if($instance['size'] == 'span12' || $instance['size'] == 'span11' || $instance['size'] == 'span10' || $instance['size'] == 'span9' || $instance['size'] == 'span8' || $instance['size'] == 'span7' || $instance['size'] == 'span6'){?><li><span>{hnn}</span> <p><?php _e('hours', 'tkingdom')?></p></li> <li><span>{mnn}</span> <p><?php _e('minutes', 'tkingdom')?></p></li> <li><span>{snn}</span> <p><?php _e('seconds', 'tkingdom')?></p><?php } ?></li>', compact: true, timezone:new Date().getTimezoneOffset()/60 * -1});
                                                    });
                                                </script>
                                            <?php }?>
                                        </a>
                                    </div>
                                <?php ?>
                            <?php } // endif check post format?>
                        </div>
                        <div class="<?php if(!empty($video_link) || has_post_thumbnail() || !empty($attachments[0])){if($instance['size'] == 'span12'){echo 'span6';}else{echo 'span12 margin-left-0 margin-top-40';};}else{echo 'span12 margin-left-0';}?> top-content-text">
                            <?php get_template_part( '/templates/parts/entry', 'meta' ); ?>
                        </div>
                    </div>
                </div><!-- row fluid -->
                <div class="clear"></div>
                <?php endwhile; ?>
                <?php endif;?>
            </div>
        <?php
        }

    }
}