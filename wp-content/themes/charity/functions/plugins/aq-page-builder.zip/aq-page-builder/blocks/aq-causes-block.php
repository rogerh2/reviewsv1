<?php
/** Events block **/

if(!class_exists('AQ_Causes_Block')) {
    class AQ_Causes_Block extends AQ_Block {

        //set and create block
        function __construct() {
            $block_options = array(
                'name' => 'Causes',
                'size' => 'span6',
            );

            //create the block
            parent::__construct('aq_causes_block', $block_options);
        }

        function form($instance) {

            $defaults = array(
                'post_number' => '5',
                'post_order' => '',
                'order_by' => '',
                'category' => '',
            );

            $instance = wp_parse_args($instance, $defaults);
            extract($instance);

            $args = array(
                'type'                     => 'services',
                'child_of'                 => 0,
                'parent'                   => '',
                'orderby'                  => 'name',
                'order'                    => 'ASC',
                'hide_empty'               => 1,
                'hierarchical'             => 1,
                'exclude'                  => '',
                'include'                  => '',
                'number'                   => '',
                'taxonomy'                 => 'ct_services',
                'pad_counts'               => false

            );
            $categories = get_categories( $args );
            $category_options = array('-1' => 'All Categories');

            foreach($categories as $one_category){
                $category_options = $category_options + array($one_category->term_id => $one_category->name);
            }

            $order_options = array(
                'ASC' => 'Ascending',
                'DESC' => 'Descending',
            );

            $order_by_options = array(
                'ID' => 'Order by Post ID',
                'author' => 'Order by Post author',
                'title' => 'Order by Post title',
                'name' => 'Order by Post name (slug)',
                'date' => 'Order by Post Date',
                'modified' => 'Order by Post Modified Date',
                'comment_count' => 'Order by number of comments',
                'rand' => 'Random order',
            );
            ?>

            <p class="description">
                <label for="<?php echo $this->get_field_id('title') ?>">
                    Title<br/>
                    <?php echo aq_field_input('title', $block_id, $title) ?>
                </label>
            </p>
            <p class="description">
                <label for="<?php echo $this->get_field_id('post_number') ?>">
                    Number of posts<br/>
                    <?php echo aq_field_input('post_number', $block_id, $post_number) ?>
                </label>
            </p>
            <p class="description half">
                <label for="<?php echo $this->get_field_id('category') ?>">
                    Select Category<br/>
                    <?php echo aq_field_select('category', $block_id, $category_options, $category) ?>
                </label>
            </p>
            <p class="description half">
                <label for="<?php echo $this->get_field_id('order_by') ?>">
                    Order By<br/>
                    <?php echo aq_field_select('order_by', $block_id, $order_by_options, $order_by) ?>
                </label>
            </p>
            <p class="description half">
                <label for="<?php echo $this->get_field_id('post_order') ?>">
                    Ordering Type<br/>
                    <?php echo aq_field_select('post_order', $block_id, $order_options, $post_order) ?>
                </label>
            </p>

        <?php

        }

        function block($instance) {
            extract($instance);
            if($category == '-1'){
                $get_page_id = get_option('id_services_page');
                if(isset($get_page_id)){
                    $category_link = get_permalink($get_page_id);
                }else{
                    $category_link = '#';
                }
            }else{
                $get_that_term = get_term($category, 'ct_services');
                $category_link = get_term_link($get_that_term, 'ct_services');
            }
            ?>
            <div class="row-fluid tabs-home">
                <div class="row-fluid">
                    <?php if(!empty($title)){?>
                        <div class="title-holder margin-bottom-45">
                            <h2 class="title-divider">
                                <span><?php echo $title?></span>
                            </h2>
                        </div>
                    <?php }?>
                </div>
                <div class="row-fluid">
                <?php
                if($category == '-1'){
                    $args = array( 'post_status' => 'publish', 'post_type' => 'services', 'posts_per_page' => $post_number, 'orderby' => $order_by, 'order' => $post_order );
                }else{
                    $args = array( 'post_status' => 'publish', 'post_type' => 'services', 'tax_query' => array(array('taxonomy' => 'ct_services','field' => 'term_id', 'terms' => $category)), 'posts_per_page' => $post_number, 'orderby' => $order_by, 'order' => $post_order );
                }

                // The Query
                $the_query = new WP_Query($args);

                if ($the_query->have_posts()): while ($the_query->have_posts()) : $the_query->the_post(); ?>
                    <?php
                        $attachments  = get_post_meta($the_query->post->ID, 'tk_repeatable', true);
                        $video_link = get_post_meta($the_query->post->ID, 'tk_video_link', true);                    
                    ?>
                <div class="span12 margin-bottom-builder margin-left-0">
                        <?php if (get_post_format() == 'video') {?>
                            <?php if($video_link){?>
                                <div class="top-content-image margin-bottom-30">
                                    <?php tk_video_player($video_link);?>
                                </div>
                            <?php }?>
                        <?php } elseif (get_post_format() == 'gallery') {?>
                            <?php if(!empty ($attachments[0])){?>
                                <div class="causes-block-gallery margin-bottom-30">
                                    <a href="<?php the_permalink()?>">
                                        <div class="flexslider">
                                            <ul class="slides">
                                                <?php
                                                    foreach($attachments as $attach) {
                                                        echo '<li><img src="'.tk_get_thumb(770, 398, $attach).'" alt="'.get_the_title().'" title="'.get_the_title().'"/></li>';
                                                    }
                                                ?>
                                            </ul>
                                        </div><!-- flex slider -->
                                    </a>
                                </div>
                            <?php }?>
                        <?php }else {?>
                            <?php if(has_post_thumbnail()){?>
                                <div class="top-content-image margin-bottom-30">               
                                    <?php                                     
                                        //checks to see what size is selected and chooses thumbnail size
                                        if($instance['size'] == 'span12' || $instance['size'] == 'span11' || $instance['size'] == 'span10' || $instance['size'] == 'span9' || $instance['size'] == 'span8' || $instance['size'] == 'span7' || $instance['size'] == 'span7'){
                                            the_post_thumbnail('home-events-full');
                                        } else {
                                            the_post_thumbnail('home-events');
                                        }
                                        $post_thumbnail = wp_get_attachment_image_src( get_post_thumbnail_id($the_query->post->ID), 'full' );
                                    ?>                                    
                                    
                                    <div class="images-hover-blog">
                                        <a href="<?php echo $post_thumbnail[0];?>" class="blog-fancybox fancybox"
                                           data-fancybox-group="gallery"
                                           title="<?php the_title()?>"></a>
                                        <a href="<?php the_permalink()?>" class="blog-link"></a>
                                    </div><!-- images-hover-blog -->
                                    
                                </div>
                            <?php }?>
                        <?php }?>
                        <div class="top-content-text">
                            <a class="tab-title-link" href="<?php the_permalink()?>"><?php the_title()?></a>
                            <p><?php the_excerpt()?></p>
                            <a href="<?php the_permalink()?>"><?php _e('Read More', 'tkingdom')?><i class="plas10"><div class="plus-up"></div><div class="plus-hor"></div></i></a>
                        </div><!-- top-content-text -->
                    </div>
                <?php endwhile; ?>
                <?php endif;?>
                </div><!-- row fluid-->

            </div>
        <?php
        }

    }
}